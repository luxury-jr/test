
let mapData = {
	type: 'FeatureCollection',
	features: [
	// 	{
	// 	type: "Feature",
	// 	properties: {
	// 		stroke: "#ff0000",
	// 		"stroke-width": 2,
	// 		"stroke-opacity": 1,
	// 		fill: "#ff0000",
	// 		"fill-opacity": 0.5,
	// 		"name": "园区",
	// 		childNum: 1
	// 	},
	// 	geometry: {
	// 		type: 'Polygon',
	// 		coordinates: [
	// 			[
	// 				[0, 0],
	// 				[1900, 0],
	// 				[1900, 900],
	// 				[0, 900]
	// 			]
	// 		]
	// 	}
	// },
	{
		type: "Feature",
		properties: {
			stroke: "#000000",
			"stroke-width": 20,
			"stroke-opacity": 1,
			fill: "#000000",
			"fill-opacity": 0.5,
			"name": "碰碰车",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[0, 900],
					[0, 546],
					[141, 546],
					[283, 900],
					[425,688],
					[637,476],
					[779,546]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "过山车",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[283, 900],
					[425, 688],
					[779, 546],
					[921, 900],
					[921,617]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "海盗船",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[921, 617],
					[921, 900],
					[1417, 617],
					[1559, 759],
					[1559, 900]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "大摆锤",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[1346, 546],
					[1559, 900],
					[1559, 759],
					[1630, 476],
					[1900, 900],
					[1900, 476]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "激流勇进",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[637, 476],
					[779, 405],
					[921, 617],
					[1062, 404],
					[1346, 546],
					[1417, 617]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "旋转木马",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[0, 546],
					[0, 0],
					[141, 546],
					[283, 476],
					[495, 0],
					[637,476],
					[779,405]
				]
			]
		}
	},
	{
		type: "Feature",
		properties: {
			stroke: "#ff0000",
			"stroke-width": 2,
			"stroke-opacity": 1,
			fill: "#ff0000",
			"fill-opacity": 0.5,
			"name": "摩天轮",
			childNum: 1
		},
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[495, 0],
					[779, 405],
					[1062, 405],
					[1346, 546],
					[1630, 476],
					[1900, 476],
					[1900, 0]
				]
			]
		}
	},
]
}