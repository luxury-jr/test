

let echarts1 = echarts.init(document.getElementById("div_hot"));

var AIRPORT_IMG_SRC = './assets/images/hot3.jpg';
var AIRPORT_IMG_SRC2 = './assets/images/分区.jpg';
var COORD_WIDTH = 1900;
var COORD_HEIGHT = 900;

echarts.registerMap('airport', {
	type: 'FeatureCollection',
	features: [{
		geometry: {
			type: 'Polygon',
			coordinates: [
				[
					[0, 0],
					[COORD_WIDTH, 0],
					[COORD_WIDTH, COORD_HEIGHT],
					[0, COORD_HEIGHT]
				]
			]
		},
		properties: {
			name: 'Afghanistan',
			childNum: 1
		}
	}]
});

echarts.registerMap('areaMap', mapData)


var app = {};
var option;

var xData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
var yData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
var timeData = ["8:00","10:00","12:00" ,"14:00","16:00","18:00","20:00","22:00"]
const sliceArray =[
	[0,50],
	[0,120],
	[0,140],
	[0,200],
	[0,200],
	[0,140],
	[0,120],
	[0,50]
];
const optionSet = {
	pointSize: 25,
	blurSize: 35,
	maxNum: 3,
	perPx: 100,
	color: ['#3cff00', '#ffdf00', '#ff0000'],
	//startColor: "#71f951",
	//locations:
	//endColor: "#C92A06",
	testRecord: [],
	tabKey: '1',
	showPoint: false
}
option = {
	baseOption: {
		tooltip: {
			formatter: function (p) {
				return "0"
			}
		},
		//底部滚动栏
		timeline: {
			axisType: 'category',
			orient: 'horizontal',
			autoPlay: true,
			//inverse: true,//滑动条往左
			playInterval: 1000,
			left: '10%',
			right: '10%',
			bottom: '3%',
			width: '80%',
			height: '50px',
			label: {
				normal: {
					textStyle: {
						color: '#fff'
					}
				},
				emphasis: {
					textStyle: {
						color: '#fff'
					}
				}
			},
			symbol: 'none',
			lineStyle: {
				color: '#555'
			},
			checkpointStyle: {
				color: '#bbb',
				borderColor: '#777',
				borderWidth: 1
			},
			controlStyle: {
				showNextBtn: false,
				showPrevBtn: false,
				normal: {
					color: '#666',
					borderColor: '#666'
				},
				emphasis: {
					color: '#aaa',
					borderColor: '#aaa'
				}
			},
			data: timeData
		},
		geo: {
			map: 'airport',
			left: -200,
			top: -100,
			right: 0,
			bottom: 0,
			roam: true,
			zoom: 1.2,
			scaleLimit: {
				min: 0.8,
				max: 3
			},
			// label: {
			// 	emphasis: {
			// 		show: false
			// 	}
			// },
			roam: true,
			itemStyle: {
				normal: {
					areaColor: 'transparent',
					borderColor: '#00ff00'
				},
				emphasis: {
					areaColor: 'transparent'
				}
			}
		},
		visualMap: {
			type: 'continuous',
			min: 0,
			max: 12,
			seriesIndex: 1,
			calculable: true,
			inRange: {
				color: optionSet.color//[optionSet.startColor, optionSet.endColor]
			},
			textStyle: {
				color: '#000'
			}
		},
		series: [
			{
				type: 'custom',
				id: 'airport',
				coordinateSystem: 'geo',
				renderItem: function (params, api) {
					var lt = api.coord([0, 0]);
					var rb = api.coord([COORD_WIDTH, COORD_HEIGHT])
					var zoom = Math.abs((rb[1] - lt[1]) / COORD_HEIGHT);//缩放值
					var mapBG = document.getElementById("mapBG");
					mapBG.style.top = rb[1] + 'px';
					mapBG.style.left = lt[0] + 'px';//设置背景图片位置
					mapBG.style.width = Math.abs(rb[0] - lt[0]) + 'px ';
					mapBG.style.height = Math.abs(rb[1] - lt[1]) + 'px';//设置背景图片宽高度
					var img = zoom < 0.5 ? AIRPORT_IMG_SRC2 : AIRPORT_IMG_SRC;//缩放值小于0.5现实另一个图片
					mapBG.src = img;
					// console.log(zoom, img);
					return {
						type: 'image',
						style: {
							image: '',
							x: lt[0],
							y: lt[1],
							width: rb[0] - lt[0],
							height: rb[1] - lt[1]
						}
					};
				},

				data: [
					[0], [1]
				]
			},
			{
				name: 'AQI',
				type: 'heatmap',
				coordinateSystem: 'geo',
				data: [],
				blurSize: optionSet.blurSize,
				pointSize: optionSet.pointSize,
				itemStyle: {
					show: true,
					color: 'rgb(0,0,0,0)'
				}
			}]
	},
	
	options: []
};


echarts1.setOption(option);

// 方法一：调用到的x，y用于生成热力图
const LoadData = function (startDay, endDay) {
	document.getElementById("showDate").innerHTML = '开始时间：' + startDay + ' 结束时间：' + endDay;
	fetch("http://175.24.112.76:8899/heat_map", {
		method: 'GET', // or 'PUT'
		// data can be `string` or {object}!
		headers: new Headers({
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		})
	}).then(res => res.json())
		.catch(error => console.error('Error:', error))
		.then(response => {
			var geoCoordMap = [];
			let count = 1;
			response.forEach(item => {
				geoCoordMap.push([item.x, item.y, item.value]);
				count = item.value;
				//count = (count + 1) % 12;
			});
			option.options = [];
			// 循环设置时间轴对应的现实数据
			for (var i = 0; i < timeData.length; i++) {
				console.log(geoCoordMap.slice(sliceArray[i][0],sliceArray[i][1]))
				option.options.push({
					visualMap: {
						type: 'continuous',
						min: 0,
						max: 12,
						seriesIndex: 1,
						calculable: true,
						inRange: {
							color: optionSet.color//[optionSet.startColor, optionSet.endColor]
						},
						textStyle: {
							color: '#000'
						}
					},
					series: [
						{
							type: 'custom',
							id: 'airport',
							coordinateSystem: 'geo',
							renderItem: function (params, api) {
								var lt = api.coord([0, 0]);
								var rb = api.coord([COORD_WIDTH, COORD_HEIGHT])
								var zoom = Math.abs((rb[1] - lt[1]) / COORD_HEIGHT);//缩放值
								var mapBG = document.getElementById("mapBG");
								mapBG.style.top = rb[1] + 'px';
								mapBG.style.left = lt[0] + 'px';//设置背景图片位置
								mapBG.style.width = Math.abs(rb[0] - lt[0]) + 'px ';
								mapBG.style.height = Math.abs(rb[1] - lt[1]) + 'px';//设置背景图片宽高度
								var img = zoom < 0.5 ? AIRPORT_IMG_SRC2 : AIRPORT_IMG_SRC;//缩放值小于0.5现实另一个图片
								mapBG.src = img;
								// console.log(zoom, img);
								return {
									type: 'image',
									style: {
										image: '',
										x: lt[0],
										y: lt[1],
										width: rb[0] - lt[0],
										height: rb[1] - lt[1]
									}
								};
							},
							itemStyle: {
								show: false,
							},
							data: [
								[0, 0]
							]
						},
						{
							name: 'AQI',
							type: 'heatmap',
							coordinateSystem: 'geo',
							data: geoCoordMap.slice(sliceArray[i][0],sliceArray[i][1]),
							blurSize: optionSet.blurSize,
							pointSize: optionSet.pointSize,
							label: {
								normal: {
									formatter: '{0}'
								},
								show: true
							},
							itemStyle: {
								show: true,
								color: 'rgb(0,0,0,0)'
							}
						}]
				});
			}
			echarts1.setOption(option);
		});

}

// 方法二：判断调用到的x，y是否在对应的区域，并将统计好的value渲染到对应的区域标签上
const LoadWarningDate = function () {
	fetch("http://175.24.112.76:8899/heat_map2", {
		method: 'GET', // or 'PUT'
		// data can be `string` or {object}!
		headers: new Headers({
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		})
	}).then(res => res.json())
		.catch(error => console.error('Error:', error))
		// 返回数组[0, 0, 0, 0, 0, 0, 0]
		.then(response => {
			const areaName = ['碰碰车', '过山车', '海盗船', '大摆锤', '激流勇进', '旋转木马', '摩天轮'];//区域名称与标签和后台区域对应
			console.log(response)
			for (let index = 0; index < response.length; index++) {
				const element = parseInt((response[index])*10);
				// 预警判断条件
				if (element > 150) {
					document.getElementById('a'+(index+1)).style.color='red'
					document.getElementById("warinngDiv").innerHTML += '<span style="width: 6px;height: 6px;border-radius: 100%;background: red;display: inline-block;margin-left: 16px;"></span>'
					document.getElementById("warinngDiv").innerHTML += '<span style="color: #666666;font-size: 13px;position: relative;top: 1px;line-height: 13px;">' + areaName[index] + '预警信息</span>'
					document.getElementById("warinngDiv").innerHTML += '<spanstyle="color: #000000;font-size: 13px;position: relative;top: 1px;line-height: 13px;">&emsp;' + areaName[index] + '附近区域人流密度过高,当前人流量为：' + element + '，请及时处理！</span><br />'
				}else{
					document.getElementById('a'+(index+1)).style.color='#000'
				}
				document.getElementById('label' + (index + 1)).innerHTML = "(" + element + ")"

			}
			console.log(response)

		});
}